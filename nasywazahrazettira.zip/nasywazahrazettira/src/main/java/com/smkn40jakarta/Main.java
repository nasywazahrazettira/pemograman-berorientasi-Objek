package com.smkn40jakarta;

public class Main {
    public static void main(String[] args) {
        Hewan Macan = new Hewan("Macan");
        Hewan Kucing = new Hewan("Kucing");
        Macan.beratHewan(6);
        Macan.jumlahKakiHewan(4);
        Macan.cetakHewan();
        Kucing.beratHewan(5);
        Kucing.jumlahKakiHewan(4);
        Kucing.cetakHewan();
         }
        
 }