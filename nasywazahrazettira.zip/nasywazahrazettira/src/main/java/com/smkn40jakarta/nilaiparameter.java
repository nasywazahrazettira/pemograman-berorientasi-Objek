package com.smkn40jakarta;

public class nilaiparameter {
    public static void hitungLuasSegitiga(double alas, double tinggi) {
            double luas = (alas * tinggi) / 2;
            System.out.println("Luas segitiga adalah: "+luas);
}
public static void main(String args[]){
            hitungLuasSegitiga(10, 15);
          }
}
