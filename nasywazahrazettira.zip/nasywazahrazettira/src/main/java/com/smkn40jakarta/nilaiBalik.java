package com.smkn40jakarta;

public class nilaiBalik {
public static void main(String[] args) {
    double s = 12;
    double hasil = hitungLuas(s); //memanggil fungsi
    System.out.println("Hasilnya adalah = " + hasil);
    }
    //fungsi dengan nilai balik
    
static double luasPersegi(double sisi){
    return sisi * sisi;
    }

// membuat fungsi luasKubus()
    static double hitungLuas(double sisi){
        
        // memanggil fungsi luasPersegi
        return 6 * luasPersegi(sisi);
    }
}